import asyncio
from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.base import TaskResult
from autogen_agentchat.messages import ModelClientStreamingChunkEvent, TextMessage

from agent_system.llms import model_client
async def main() -> None:
    agent = AssistantAgent("assistant", model_client=model_client, model_client_stream=True)
    async for message in agent.run_stream(task="编写一首七言绝句"):
        if isinstance(message, ModelClientStreamingChunkEvent):
            print(message.content)
        elif isinstance(message, TextMessage) and message.models_usage is not None:
            print(message.models_usage.completion_tokens)
        elif isinstance(message, TaskResult):
            print(message.messages[1].content)

asyncio.run(main())