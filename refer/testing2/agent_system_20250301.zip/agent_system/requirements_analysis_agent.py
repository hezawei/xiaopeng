import asyncio

from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.conditions import SourceMatchTermination
from autogen_agentchat.teams import RoundRobinGroupChat
from autogen_agentchat.ui import Console
from docling.document_converter import DocumentConverter
from llms import model_client

from pydantic import BaseModel, Field
from typing import Optional

class BusinessRequirement(BaseModel):
    requirement_id: str = Field(..., description="需求编号")
    requirement_name: str = Field(..., description="业务需求名称")
    requirement_type: str = Field(..., description="需求类别:[功能需求/性能需求/安全需求/其它需求]")
    parent_requirement: Optional[str] = Field(None, description="父需求")
    module: str = Field(..., description="所属模块")
    requirement_level: str = Field(..., description="需求层级")
    reviewer: str = Field(..., description="评审人")
    estimated_hours: int = Field(..., description="预计完成工时", gt=0)
    description: str = Field(..., description="需求描述")
    acceptance_criteria: str = Field(..., description="验收标准")

class BusinessRequirementList(BaseModel):
    business_requirements: list[BusinessRequirement] = Field(..., description="业务需求列表")

async def get_document_from_file():
    """获取需求文件内容"""
    source = "05-ucmp_V1.1.8.pdf"  # document per local path or URL
    converter = DocumentConverter()
    result = converter.convert(source)
    return result.document.export_to_markdown()

async def structure_requirement(content: str) -> BusinessRequirementList:
    """结构化需求信息"""
    from pydantic_ai import Agent
    from pydantic_ai.models.openai import OpenAIModel

    model = OpenAIModel(
        'deepseek-chat',
        base_url='https://api.deepseek.com',
        api_key='sk-e5b2a319f9ce4d0fb71c5dc96596a69d',
    )
    agent = Agent(model, result_type=BusinessRequirementList)
    result = await agent.run(user_prompt=f"对下面内容进行结构化输出:\n{content}")
    return result.data

async def insert_into_database(requirements: BusinessRequirementList):
    """将需求数据插入数据库"""
    from db import BusinessRequirementCRUD
    for requirement in requirements.business_requirements:
        BusinessRequirementCRUD.create(requirement)


# 需求获取智能体
requirement_acquisition_agent = AssistantAgent(
    name="requirement_acquisition_agent",
    model_client=model_client,
    tools=[get_document_from_file],
    system_message="调用工具获取文档内容",
    model_client_stream=False,
)

req_analysis_prompt="""
根据如下格式的需求文档，进行需求分析，输出需求分析报告：

## 1. Profile
**角色**：高级测试需求分析师  
**核心能力**：
- 需求结构化拆解与可测试性转化
- 风险驱动的测试策略设计
- 全链路需求追溯能力

## 2. 需求结构化框架
### 2.1 功能需求分解
```markdown
- [必选] 使用Markdown无序列表展示功能模块
- [必选] 标注规则：
  - 核心功能：★（影响核心业务流程）
  - 高风险功能：⚠️（含外部依赖/复杂逻辑）
- 示例：
  - 订单风控引擎（★⚠️）：实时交易风险评估
```

### 2.2 非功能需求矩阵
```markdown
| 维度       | 指标项                 | 验收标准            |
|------------|------------------------|---------------------|
| 性能       | 支付接口响应时间       | ≤1.2s(P99)         |
| 安全性     | 敏感信息加密           | AES-256+SSL/TLS1.3 |
```

### 2.3 业务规则提取模板
```markdown
- 规则编号：BR-{模块缩写}-001
- 触发条件：当[条件]时
- 系统行为：应执行[动作]
- 示例：
  BR-PAY-003：当连续验证失败3次时，锁定账户1小时
```

## 3. 深度分析指令
### 3.1 可测试性评估表
```markdown
| 需求ID | 可测性(1-5) | 缺陷描述               | 优化建议            |
|--------|-------------|------------------------|---------------------|
| F-012  | 2           | "良好的用户体验"无量化 | 增加页面加载进度条 |
```

### 3.2 测试策略蓝图
```markdown
- [分层策略] 
  █ 单元测试(30%) → 接口测试(40%) → E2E测试(20%) → 探索测试(10%)
- [工具链] 
  Jest(单元) + Postman(接口) + Cypress(E2E) + OWASP ZAP(安全)
```

### 3.3 风险热点地图
```markdown
🔥 高风险区（立即处理）：
- 第三方身份认证服务降级
- 支付金额计算精度丢失

🛡️ 缓解措施：
- 实施接口mock方案
- 增加金额四舍五入审计日志
```

## 4. 增强版输出规范
### 4.1 文档结构
```markdown
## 四、测试追踪矩阵
| 需求ID | 测试类型 | 用例数 | 自动化率 | 验收证据 |
|--------|----------|--------|----------|----------|

## 五、环境拓扑图
- 测试集群配置：4C8G*3节点
- 特殊设备：iOS/Android真机测试架
```

### 4.2 用例设计规范
```markdown
**TC-风险场景验证**：
- 破坏性测试步骤：
  1. 模拟第三方API返回500错误
  2. 连续发送异常报文10次
- 预期韧性表现：
  - 系统自动切换备用服务节点
  - 触发告警通知运维人员
```

## 5. 智能增强模块
```markdown
[!AI辅助提示] 建议执行：
1. 使用决策表分析登录模块的组合场景
2. 对核心API进行Swagger规范校验
3. 生成需求覆盖率热力图（使用JaCoCo）
```
"""
# 需求分析智能体
requirement_analysis_agent = AssistantAgent(
    name="requirement_analysis_agent",
    model_client=model_client,
    system_message=req_analysis_prompt,
    model_client_stream=False,
)
# 需求输出智能体
requirement_output_agent = AssistantAgent(
    name="requirement_output_agent",
    model_client=model_client,
    system_message="""
    请根据需求分析报告进行详细的需求整理，尽量覆盖到报告中呈现所有的需求内容，每条需求信息都参考如下格式，最终以列表形式输出：
    业务需求名称：[实际需求名称]
    需求类别：[功能需求/性能需求/安全需求/其它需求]
    父需求：[该需求是上级需求]
    所属模块：[所属的业务模块]
    需求层级：[BR]
    评审人：[田老师]
    预计完成工时:**小时
    需求描述：作为一名<某类型的用户>，我希望<达成某些目的>，这样可以<开发的价值>。\n 验收标准：[明确的验收标准]
    """,
    model_client_stream=False,
)

# 需求信息结构化
requirement_structure_agent = AssistantAgent(
    name="requirement_structure_agent",
    model_client=model_client,
    tools=[structure_requirement],
    system_message="调用工具对软件测试需求进行格式化",
    model_client_stream=False,
)

# 需求入库智能体
requirement_into_db_agent = AssistantAgent(
    name="requirement_into_db_agent",
    model_client=model_client,
    tools=[insert_into_database],
    system_message="""调用工具将需求数据插入到数据库""",
    model_client_stream=False,
)

source_termination = SourceMatchTermination(sources=["requirement_into_db_agent"])

team = RoundRobinGroupChat([requirement_acquisition_agent, requirement_analysis_agent,requirement_output_agent, requirement_structure_agent, requirement_into_db_agent],
                           termination_condition=source_termination)

async def main():
    await Console(team.run_stream(task="开始需求分析"))

asyncio.run(main())

# 优化代码：1、增加评审智能体（考虑用户是否参与）2、优化提示词 3、增加需求获取的来源（文档、用户输入.....）4、插入数据库（建议调用系统入库接口）