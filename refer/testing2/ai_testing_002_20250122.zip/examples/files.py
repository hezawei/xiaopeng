# from 父 import 儿子
from tools import tt
